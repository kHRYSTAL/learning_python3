#!/usr/bin/env python
# -*- coding:utf-8 -*-

# @version: ??
# @usage: 模块示例
# @author: kHRYSTAL
# @license: Apache Licence 
# @contact: khrystal0918@gmail.com
# @site: https://github.com/kHRYSTAL
# @software: PyCharm
# @file: module_test.py
# @time: 17/6/1 上午11:18

module_name = 'module'


def test():
    print("hello module")

def logger():
    print('in the module')

if __name__ == '__main__':
    pass

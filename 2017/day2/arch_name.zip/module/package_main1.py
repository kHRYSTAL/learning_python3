#!/usr/bin/env python
# -*- coding:utf-8 -*-

# @version: ??
# @usage: 
# @author: kHRYSTAL
# @license: Apache Licence 
# @contact: khrystal0918@gmail.com
# @site: https://github.com/kHRYSTAL
# @software: PyCharm
# @file: package_main1.py
# @time: 17/6/1 下午4:17

from package_test1 import package_module1

package_module1.test()

if __name__ == '__main__':
    pass
#!/usr/bin/env python
# -*- coding:utf-8 -*-

# @version: ??
# @usage: 
# @author: kHRYSTAL
# @license: Apache Licence 
# @contact: khrystal0918@gmail.com
# @site: https://github.com/kHRYSTAL
# @software: PyCharm
# @file: package_module1.py
# @time: 17/6/1 下午4:14


def test():
    print('in the module1')


if __name__ == '__main__':
    pass
